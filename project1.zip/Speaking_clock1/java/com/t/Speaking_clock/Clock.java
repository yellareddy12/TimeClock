package com.t.Speaking_clock;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class Clock {
	@GetMapping("/time/{hours}:{minutes}")
	public String getCurrentTime(@PathVariable int hours, @PathVariable int minutes) {
        return Time.convertTimeToWords(hours, minutes);
    }
}
