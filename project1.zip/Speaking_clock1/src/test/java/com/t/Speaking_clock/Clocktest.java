package com.t.Speaking_clock;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.Assert.assertEquals;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class Clocktest {
	@Autowired
    private Clock controller;

    private MockMvc mockMvc;

    @Test
    public void testGetCurrentTime() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/time/3:15"))
                .andExpect(status().isOk())
                .andReturn();
        assertEquals("It's three fifteen", result.getModelAndView().getModel());
    }
}
