package com.t.Speaking_clock;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.t.Speaking_clock.Time;

public class Timetest {
	@Test
    public void testConvertTimeToWords_Midnight() {
        String result = Time.convertTimeToWords(0, 0);
        assertEquals("It's Midnight", result);
    }

    @Test
    public void testConvertTimeToWords_Midday() {
        String result = Time.convertTimeToWords(12, 0);
        assertEquals("It's Midday", result);
    }

    @Test
    public void testConvertTimeToWords_SimpleTime() {
        String result = Time.convertTimeToWords(3, 15);
        assertEquals("It's three fifteen", result);
    }

    @Test
    public void testConvertTimeToWords_ComplexTime() {
        String result = Time.convertTimeToWords(9, 47);
        assertEquals("It's nine forty seven", result);
    }

}
